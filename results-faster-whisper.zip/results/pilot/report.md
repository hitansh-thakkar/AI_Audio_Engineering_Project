# Pilot audio pipeline report

Processed **12 of 833** manifest WAVs (**0.021 hours**). The source dataset remains intact. Its 16 extra WAVs are byte-identical to mapped recordings.

| Scoring set | Clips | Original WER | Processed WER | Original CER | Processed CER |
|---|---:|---:|---:|---:|---:|
| Overall excluding Sindhi | 11 | 78.23% | 78.23% | 45.48% | 45.48% |
| All clips, literal script | 12 | 83.33% | 83.33% | 54.73% | 54.73% |
| Sindhi, literal script | 1 | 115.00% | 115.00% | 128.21% | 128.21% |
| Clips with a separated interval | 0 | N/A | N/A | N/A | N/A |

**Diarization error rate was 77.24%** over 2 clips with timed speaker references and 15.63 reference speaker-seconds. Scoring used the full clip, a zero collar, and overlap-inclusive DER. The supplied timed references contain serial speaker turns.

Pyannote detected **0 overlap intervals** across 0 clips. SepFormer separated **0 intervals** totaling 0.00 seconds. The pipeline resolved both source-to-speaker assignments in 0 of those intervals. Separation included 0 intervals shorter than 100 ms. Intervals with more than two detected speakers (0) kept mixed audio. Speaker labels are local to each recording.

Scores sum edit counts before dividing by total reference units. Unicode was case-folded and NFC-normalized, punctuation and symbols were replaced by spaces, and CER omits whitespace. Sindhi has a known Devanagari/Perso-Arabic script mismatch, so its literal scores appear separately.

Both conditions used the same CUDA float16 Whisper decoder, beam size 5, word timestamps, and clip language policy. The code-switch register used batch-item language detection. For the processed condition, the main stream uses the primary source within separated intervals, and words from the secondary stream are merged chronologically. The original and processed runs returned different text on 0 clips with identical input audio.

**GPU** NVIDIA GeForce RTX 5090, CUDA 12.8. This invocation reused 12 complete checkpoints. Processing wall time for new clips was 0.0 seconds.

| Stage | Cumulative seconds |
|---|---:|
| Audio preparation | 0.00 |
| Diarization | 0.34 |
| Separation | 0.00 |
| Asr original | 2.44 |
| Asr processed | 2.39 |
| Evaluation | 0.00 |

[ASR comparison](asr_comparison.png) · [Runtime chart](runtime.png) · [Per-clip measurements](metrics.csv) · [Metrics and edit counts](metrics.json) · [Timestamped transcripts and speaker turns](transcripts.jsonl) · [Separated stereo stems](separated_stems.zip)
