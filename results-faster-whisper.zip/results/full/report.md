# Full audio pipeline evaluation

**Use original-audio Whisper as the transcription baseline for this dataset.** The combined pipeline produced worse transcripts than that baseline. Nearly all of the additional word edits came from the 35 clips where the pipeline applied separation. The saved transcripts show repeated text from a secondary track in some of the largest failures. The dataset supports this end-to-end transcription comparison and a small diarization evaluation. Its annotations leave overlap detection and the quality of the separated audio unverified.

## What was evaluated

The run covers all **833 manifest recordings**, about **1.84 hours** of 16 kHz mono audio across four corpora and 15 language labels. I matched the saved transcripts to all 833 manifest IDs and verified that their reference text matches the manifest. The 16 additional WAVs listed in the dataset audit are duplicates and are outside the scoring set.

Both conditions used the same reported Whisper decoding settings (CUDA float16, beam size 5, word timestamps, and the same language policy). The original condition transcribed the mixed audio. The processed condition used a primary source within intervals selected for separation and merged secondary-track words into the transcript in timestamp order. Code-switch clips used language detection per batch item.

## Transcription results

Word error rate (WER) and character error rate (CER) count substitutions, deletions, and insertions per reference word or character. Because extra output counts as insertions, either rate can exceed 100%. The table pools edit counts and reference units across each group. Scoring case-folds and NFC-normalizes text, replaces punctuation and symbols with spaces, and omits whitespace for CER.

| Scoring set | Clips | Original WER | Processed WER | Original CER | Processed CER |
|---|---:|---:|---:|---:|---:|
| Overall excluding Sindhi | 782 | 88.59% | 93.56% | 54.07% | 58.73% |
| All clips, literal script | 833 | 90.32% | 94.92% | 55.97% | 60.99% |
| No separated interval, all languages | 798 | 89.27% | 89.29% | 55.19% | 55.20% |
| At least one separated interval, all languages | 35 | 117.39% | 240.91% | 76.44% | 212.42% |
| At least one separated interval, excluding Sindhi | 32 | 118.46% | 255.60% | 75.87% | 208.06% |

The main comparison excludes Sindhi because the references use Devanagari and Whisper can return Perso-Arabic text. The 51 Sindhi clips scored 111.48% → 111.58% WER and 84.14% → 94.54% CER under literal comparison. Interpreting Sindhi recognition quality requires scoring in a common script.

### What drove the increase

- Across all clips, processing added **627 net word edits**. The separation subset accounted for **625** of those edits and **622** additional word insertions. In that subset, **24 clips worsened, 8 tied, and 3 improved** by word-edit count.
- In Hindi clip `iv_hi_012`, the original transcript had three word substitutions. The processed transcript kept those three substitutions and added **45 word insertions**. The saved secondary speaker track contains repeated “लिए” after a detected interval of about **0.51 seconds**.
- Three clips (`nir_gu_002`, `vaani_pa_007`, and `vaani_mr_003`) contributed **315** of the net extra word edits. As a sensitivity check, removing those three from the comparison excluding Sindhi still gives **88.42% → 90.90% WER**. The three clips that improved by word-edit count gained no exact word matches, and two of the three had more character edits.
- Of the 798 clips without separation, 796 produced identical text. The other two show small output differences despite the same input audio and account for the remaining two net word edits.

### Performance by language

The baseline was strongest on the sampled English and Urdu clips. The English results come from the English register, and the Hindi row includes 24 Hindi–English code-switch clips. On those code-switch clips alone, WER was **48.48%** in both conditions. Language comparisons reflect the clips and corpus mix available for each language.

| Language | Clips | Original WER | Processed WER | Original CER | Processed CER |
|---|---:|---:|---:|---:|---:|
| Assamese | 60 | 146.29% | 146.29% | 128.62% | 124.77% |
| Bengali | 60 | 90.32% | 90.55% | 54.29% | 58.25% |
| English | 40 | 7.61% | 7.61% | 3.26% | 3.26% |
| Gujarati | 43 | 92.37% | 121.65% | 70.97% | 78.09% |
| Hindi | 84 | 41.24% | 45.60% | 23.85% | 27.61% |
| Kannada | 60 | 89.21% | 89.21% | 47.82% | 47.89% |
| Malayalam | 55 | 116.67% | 116.78% | 75.96% | 76.43% |
| Marathi | 60 | 83.78% | 95.08% | 36.64% | 53.32% |
| Nepali | 60 | 98.40% | 103.33% | 41.31% | 52.33% |
| Punjabi | 60 | 108.63% | 114.70% | 61.93% | 63.50% |
| Sanskrit | 40 | 98.91% | 108.97% | 27.97% | 38.22% |
| Sindhi (literal script) | 51 | 111.48% | 111.58% | 84.14% | 94.54% |
| Tamil | 60 | 104.47% | 103.81% | 52.77% | 53.79% |
| Telugu | 60 | 118.19% | 123.86% | 66.55% | 78.57% |
| Urdu | 40 | 19.08% | 19.08% | 8.63% | 8.63% |

## Speaker diarization

Timed reference speaker turns exist for **24 Hindi–English code-switch clips**, covering **116.36 reference speaker-seconds**. This subset scored **63.67% diarization error rate (DER)**. Missed speaker time contributed **45.74 percentage points**, speaker confusion **17.05**, and false alarms **0.88**. The largest measured problem was missed reference speech time. Scoring covered the full clip with a zero collar and included overlap in the scoring policy. The reference turns themselves were sequential.

## Overlap detection and separation

Pyannote flagged **42 intervals across 35 clips**. SepFormer processed all 42, totaling **21.43 seconds**, including five intervals shorter than 100 ms. The pipeline assigned both outputs to estimated speakers in 38 intervals. These are counts of pipeline outputs. The available speaker annotations contain zero overlapping turns, and only one of the 35 flagged clips has timed speaker references. With these labels, overlap precision and recall, speaker-assignment accuracy, and the quality of the separated stems remain unmeasured.

The next evaluation should use clips with verified overlapping turns and per-speaker reference transcripts. Comparing original audio, the processed primary stream alone, and the full merged output on those clips would help identify where the additional errors enter. Clean source tracks, where available, would also let the evaluation measure separation quality directly.

## Runtime

The run used an NVIDIA GeForce RTX 5090 with CUDA 12.8. The final invocation reused **829 checkpoints** and spent **5.51 seconds** processing the **four new clips**. Full-run end-to-end wall time from a fresh start is unavailable in the saved invocation. The saved cumulative stage seconds are listed below.

| Stage | Cumulative seconds |
|---|---:|
| Audio preparation | 0.26 |
| Diarization | 33.37 |
| Separation | 1.58 |
| Original ASR | 127.65 |
| Processed ASR | 138.68 |
| Evaluation | 0.19 |

## Evidence

[Source manifest](../../../manifest.jsonl) · [Dataset audit](../dataset_audit.json) · [Per-clip metrics](metrics.csv) · [Aggregate metrics](metrics.json) · [Timestamped transcripts](transcripts.jsonl)

[Reference speaker turns](reference.rttm) · [Predicted speaker turns](predicted.rttm) · [Separated stems](separated_stems.zip) · [Runtime details](runtime.json)

[ASR comparison chart](asr_comparison.png) · [Diarization chart](diarization.png) · [Runtime chart](runtime.png)
